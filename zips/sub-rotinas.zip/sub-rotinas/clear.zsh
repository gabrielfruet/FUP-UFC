#!/usr/bin/env zsh
rm -rf ./bin/*.o
